﻿using Model;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repositories
{
    public class BookRepoDB : IItemsByRepo<authorDBRepo, BookRepoDB>
    {
        private string _connection;

        public BookRepoDB(string connection)
        {
            _connection = connection;
        }

        public bool Create(authorDBRepo x)
        {
            throw new NotImplementedException();
        }

        public bool Delete(authorDBRepo x)
        {
            throw new NotImplementedException();
        }

        public authorDBRepo Find(string id)
        {
            throw new NotImplementedException();
        }

        public IList<Book> FindAll()
        {
            //string connection = "Itegrated Security=true;Initial Catalog=pubs;Data Source=(local);";
            string sql = "SELECT * FROM titles";

            List<Book> books = new List<Book>();

            using (SqlConnection conn = new SqlConnection(_connection))
            {
                conn.Open();

                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Book book = new Book()
                            {
                                title_id = reader["title_id"].ToString(),
                                title = reader["title"].ToString(),
                                //price = reader.GetDecimal(reader.GetOrdinal("price"))
                            };

                            books.Add(book);
                        }
                    }
                }
            }

            return books;
        }

        public IList<authorDBRepo> ItemsFor(BookRepoDB x)
        {
            throw new NotImplementedException();
        }

        public bool Update(authorDBRepo x)
        {
            throw new NotImplementedException();
        }

        IList<authorDBRepo> IRepository<authorDBRepo>.FindAll()
        {
            throw new NotImplementedException();
        }
    }
}
