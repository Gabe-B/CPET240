﻿using System;

namespace Model
{
	public class Author
	{
		public string au_id { get; set; }
		public string au_fname { get; set; }
		public string au_lname { get; set; }

		//Other Fields

		public string au_phone { get; set; }
		public string au_address { get; set; }
		public string au_city { get; set; }
		public string au_state { get; set; }
		public string au_zip { get; set; }
		public int au_contract { get; set; }
	}

	public class Book
    {
		public string title_id;
		public string title;
		public string type;
		public string pub_id;
		public Decimal ? price;
		public Int32 ? ytd_sales;
		public DateTime pubdate;
    }
}
