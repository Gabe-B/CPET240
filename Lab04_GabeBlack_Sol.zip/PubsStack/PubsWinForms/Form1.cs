﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Extensions.Configuration;

using Model;
using Repositories;
using ViewModels;
using PubsServiceBus;

namespace PubsWinForms
{
    public partial class frmMain : Form
    {
        ServiceBus _service;

        public frmMain()
        {
            InitializeComponent();

            string con = GetConnection();

            authorDBRepo au_repo = new authorDBRepo(con);

            _service = new ServiceBus(au_repo);

            lvAuthors.View = View.Details;
            lvAuthors.FullRowSelect = true;
            lvAuthors.MultiSelect = false;
            lvAuthors.GridLines = true;

            lvAuthors.Columns.Add("First");
            lvAuthors.Columns.Add("Last");
            lvAuthors.Columns.Add("Phone #");
            lvAuthors.Columns.Add("Address");
            lvAuthors.Columns.Add("City");
            lvAuthors.Columns.Add("State");
            lvAuthors.Columns.Add("ZIP");
            lvAuthors.Columns.Add("Contract");

            ListViewItem item;

            List<AuthorViewModel> authors = _service.findAllAuthors();

            foreach(AuthorViewModel au in authors)
            {
                item = new ListViewItem(au.FirstName);
                item.SubItems.Add(au.LastName);
                item.SubItems.Add(au.Phone);
                item.SubItems.Add(au.Address);
                item.SubItems.Add(au.City);
                item.SubItems.Add(au.State);
                item.SubItems.Add(au.Zip);
                item.SubItems.Add(au.Contract.ToString());
                item.Tag = au.ID;
                lvAuthors.Items.Add(item);
            }
            lvAuthors.AutoResizeColumns(ColumnHeaderAutoResizeStyle.ColumnContent);
            lvAuthors.AutoResizeColumns(ColumnHeaderAutoResizeStyle.HeaderSize);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        static string GetConnection()
        {
            IConfiguration Configuration;

            var builder = new ConfigurationBuilder().AddJsonFile("appsettings.json", optional: false, reloadOnChange: false);

            Configuration = builder.Build();

            string con = Configuration["Configuration:pubsDBSConnectionString"];

            return con;
        }

        private void lvAuthors_SelectedIndexChanged(object sender, EventArgs e)
        {
            //check for unselected
            if(lvAuthors.SelectedItems.Count <= 0)
            {
                return;
            }

            ListViewItem item = lvAuthors.SelectedItems[0];

            txtTempID.Text = (string)item.Tag;
            txtFName.Text = (string)item.SubItems[0].Text;
            txtLName.Text = (string)item.SubItems[1].Text;
            txtPhoneNum.Text = (string)item.SubItems[2].Text;
            txtAddress.Text = (string)item.SubItems[3].Text;
            txtCity.Text = (string)item.SubItems[4].Text;
            txtState.Text = (string)item.SubItems[5].Text;
            txtZIP.Text = (string)item.SubItems[6].Text;
            txtContract.Text = (string)item.SubItems[7].Text;
        }

        private void txtLName_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblID_Click(object sender, EventArgs e)
        {

        }

        private void txtTempID_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblPhone_Click(object sender, EventArgs e)
        {

        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            string con = GetConnection();
            authorDBRepo au_repo = new authorDBRepo(con);
            _service = new ServiceBus(au_repo);

            Author au = _service.FindAuthor(lvAuthors.SelectedItems[0].Tag.ToString());

            ListViewItem item = lvAuthors.SelectedItems[0];

            au.au_lname = txtLName.Text.ToString();
            au.au_fname = txtFName.Text.ToString();
            au.au_phone = txtPhoneNum.Text.ToString();
            au.au_address = txtAddress.Text.ToString();
            au.au_city = txtCity.Text.ToString();
            au.au_state = txtState.Text.ToString();
            au.au_zip = txtZIP.Text.ToString();
            au.au_contract = Convert.ToInt32(txtContract.Text);

            au_repo.Update(au);

            item.SubItems[0].Text = txtFName.Text;
            item.SubItems[1].Text = txtLName.Text;
            item.SubItems[2].Text = txtPhoneNum.Text;
            item.SubItems[3].Text = txtAddress.Text;
            item.SubItems[4].Text = txtCity.Text;
            item.SubItems[5].Text = txtState.Text;
            item.SubItems[6].Text = txtZIP.Text;
            item.SubItems[7].Text = txtContract.Text;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string con = GetConnection();
            authorDBRepo au_repo = new authorDBRepo(con);
            _service = new ServiceBus(au_repo);

            if((Convert.ToInt32(txtContract.Text) != 0) && (Convert.ToInt32(txtContract.Text) != 1))
            {
                MessageBox.Show("Please enter either '1' for true or '0' for false.");
                return;
            }

            Author newAuthor = new Author();
            newAuthor.au_id = txtTempID.Text.ToString();
            newAuthor.au_lname = txtLName.Text.ToString();
            newAuthor.au_fname = txtFName.Text.ToString();
            newAuthor.au_phone = txtPhoneNum.Text.ToString();
            newAuthor.au_address = txtAddress.Text.ToString();
            newAuthor.au_city = txtCity.Text.ToString();
            newAuthor.au_state = txtState.Text.ToString();
            newAuthor.au_zip = txtZIP.Text.ToString();
            newAuthor.au_contract = Convert.ToInt32(txtContract.Text);

            au_repo.Create(newAuthor);

            ListViewItem item;
            item = new ListViewItem(newAuthor.au_fname);
            item.SubItems.Add(newAuthor.au_lname);
            item.SubItems.Add(newAuthor.au_phone);
            item.SubItems.Add(newAuthor.au_address);
            item.SubItems.Add(newAuthor.au_city);
            item.SubItems.Add(newAuthor.au_state);
            item.SubItems.Add(newAuthor.au_zip);
            item.SubItems.Add(newAuthor.au_contract.ToString());
            item.Tag = newAuthor.au_id;
            lvAuthors.Items.Add(item);
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            DialogResult dlgR = MessageBox.Show("Are you sure you want to delete this author?", "DELETE", MessageBoxButtons.YesNo);

            if(dlgR == DialogResult.Yes)
            {
                string con = GetConnection();
                authorDBRepo au_repo = new authorDBRepo(con);
                _service = new ServiceBus(au_repo);

                Author au = _service.FindAuthor(lvAuthors.SelectedItems[0].Tag.ToString());

                au_repo.Delete(au);

                lvAuthors.SelectedItems[0].Remove();
            }
        }
    }
}
